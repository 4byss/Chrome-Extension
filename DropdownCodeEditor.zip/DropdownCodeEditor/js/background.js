// console.log("background.js executed!");

// chrome.browserAction.onClicked.addListener(buttonClicked);

// function buttonClicked() {
//   prompt("Please enter your code:", "");
// }
